<?php

namespace common\modules\pagamento;

/**
 * pagamento module definition class
 */
class Pagamento extends \yii\base\Module
{
    /**
     * @inheritdoc
     */
    public $controllerNamespace = 'common\modules\pagamento\controllers';

    /**
     * @inheritdoc
     */
    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
